console.log('Hello World! This is a test from post-install instructions for altv-install');
